﻿
using UnityEngine;
using UnityEditor;
using Cainos.LucidEditor;

namespace Cainos.PixelArtPlatformer_Dungeon
{

    [CustomEditor(typeof(Switch))]
    public class SwitchEditor : Cainos.LucidEditor.LucidEditor
    {
    }
}
