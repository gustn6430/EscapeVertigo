﻿using UnityEngine;
using UnityEditor;
using Cainos.LucidEditor;

namespace Cainos.PixelArtPlatformer_Dungeon
{

    [CustomEditor(typeof(Door))]
    public class DoorEditor : LucidEditor.LucidEditor
    {
    }
}
