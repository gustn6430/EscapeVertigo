﻿using UnityEngine;
using UnityEditor;
using UnityEditor.SceneManagement;
using Cainos.LucidEditor;

namespace Cainos.PixelArtPlatformer_Dungeon
{

    [CustomEditor(typeof(Chest))]
    public class ChestEditor : LucidEditor.LucidEditor
    {
    }
}
